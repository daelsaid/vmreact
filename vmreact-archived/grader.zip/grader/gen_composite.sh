$1=input_csv 
$2=output_csv

python run_composite_scoring.py ${input_csv} ${output_csv}
